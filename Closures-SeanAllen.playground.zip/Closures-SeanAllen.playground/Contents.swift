// Swift Closures Explained
// Reference: https://www.youtube.com/watch?v=ND44vQ5iJyc

import UIKit

struct Student {
    let name: String
    let testScore: Int
}

let students = [
    Student(name: "Luke", testScore: 88),
    Student(name: "Han", testScore: 73),
    Student(name: "Leia", testScore: 95),
    Student(name: "Chewy", testScore: 78),
    Student(name: "Obi-Wan", testScore: 65),
    Student(name: "Ahsoka", testScore: 86),
    Student(name: "Yoda", testScore: 68)]
/*
// Let's create a closure to filter out the students by their test score
*/

/// 001
// Here we create our variable "topStudentFilter" of-type
//var topStudentFilter: () -> () = { }

/// 002
// First set of parentesys () is the parameters, we don't ned to name them just say the TYPE
//var topStudentFilter: (Student) -> () = { }

/// 003
// Second set of parentesys () is the return value, it can be a TYPE or Void (Void is same as empty parentesys)
//var topStudentFilter: (Student) -> () = { } // Same as -> Void
//var topStudentFilter: (Student) -> Void = { } // Same as -> ()

/// 004
// We will return a Bool because we will filter the students and check if their score is the expected
//var topStudentFilter: (Student) -> Bool = { }

/// 005
// Here we name the paramenter "student0", we can name it anything
var topStudentFilter: (Student) -> Bool = { student0 in // The TYPE here is the FUNCTION signature
    return student0.testScore > 80
}

/// 006
// So now we will create a Function that does the same thing
func topStudentFilterFunction(student0: Student) -> Bool { // You can see they are quite similar
    return student0.testScore > 70
}

/// 007
// Now that we have our CLOSURE, we are going to pass it around using our VARIABLE
//let topStudents = students.filter(<#T##isIncluded: (Student) throws -> Bool##(Student) throws -> Bool#>) // You can see that it asks for a parameter and the closure need to have the same call or it won't accept
let topStudents = students.filter(topStudentFilter) // You can see FILTER takes in a CLOSURE
for topStudent in topStudents {
    print(topStudent.name)
}

/// 008
// Now we can do the same thing using the FUNCTION as FILTER
let topStudentsFunction = students.filter(topStudentFilterFunction) // Will have bigger list because rule is > 70, but works the same
for topStudent in topStudentsFunction {
    print(topStudent.name)
}

/// 009
// Now lets talk about short-hand notation { $0 > $1 }

// we will start by rewritting the Filter
//let topStudents = students.filter(<#T##isIncluded: (Student) throws -> Bool##(Student) throws -> Bool#>) // Hitting ENTER will enter the Trailing Closure Syntax bellow
/*
 let topStudentsShort = students.filter { <#Student#> in //
    <#code#>
}
 */

// Here we don't need to define the TYPE is because it already knows that it TYPE Students, so we can just name the parameter
// But if I don't want to name the parameter I can use the shorthand $0 for first parameter, $1 for second one and so forth
let topStudentsShort = students.filter { $0.testScore > 80 }


// Now lets sort this so you can see the shorthand for $0 and $1
//let studentRanking = topStudents.sorted(by: <#T##(Student, Student) throws -> Bool#>) // Reminder, if you are going to use FILTER or SORTED or a function of yours the closure need to match exactly
let studentRanking = topStudents.sorted { studentOne, studentTwo in // IF the closure is the last parameter you can omit it and use the {} syntax directly [Note: Very used in SwiftUI]
    return studentOne.testScore > studentTwo.testScore
}
let studentRankingShort = topStudents.sorted { $0.testScore > $1.testScore } // Would look like this is shorthand

// Looking in SwiftUI, when you create a VStack you do it like this
/*
 VStack {
    Text(title)
        .bold()
        .cornerRadius(8)
 }
 */
// But what you are not seeing is that it's actually a closure
/*
 VStack(aligment: .leading, spacing: 10, () -> _ ) { // Hold optinal here to get all the parameters, and since closure is the last parameter it can be ommited
    Text(title) // SwiftUI is riddled with closures and default values
        .bold()
        .cornerRadius(8)
 }
 */

// What is @escaping ?
// Example:

//func getFollowers(for username: String, page: Int, completed @escaping (Result<[Follower], GFError>) -> (Void)) {}
// In case of Network calls the answer could take longer, so ESCAPING makes the closude live on longer than the method that called it, but be careful not to cause memory leaks, and use weak self when calling it
