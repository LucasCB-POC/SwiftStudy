// High Order Functions - Filter, Map, Reduce, CompactMap, FlatMap
//Reference: https://www.youtube.com/watch?v=-mx_Kf3qKJY

import UIKit

struct IndieApp {
    let name: String
    let monthlyPrice: Double
    let users: Int
}

let appPortifolio = [IndieApp(name: "Creator View", monthlyPrice: 11.99, users: 4356),
                     IndieApp(name: "FitHero", monthlyPrice: 0.00, users: 1756),
                     IndieApp(name: "FitHero2", monthlyPrice: 0.00, users: 101),
                     IndieApp(name: "Buckets", monthlyPrice: 3.99, users: 7598),
                     IndieApp(name: "Connect Four", monthlyPrice: 1.99, users: 34081)]

// MARK: - Filter
let freeApps = appPortifolio.filter { $0.monthlyPrice == 0.0 }
print(freeApps)

let highUsers = appPortifolio.filter { $0 .users > 5000 }
// Same as, but in a One-Liner
//for app in appPortifolio {
//    if app.users > 5000 {
//        highUsers.append(app)
//    }
//}
print(highUsers)

// MARK: - Map
// commin use of Map is to pull out all the specific properties

let appNames = appPortifolio.map { $0.name }
print(appNames) // So you can get all the names of the apps

let appNamesSorted = appPortifolio.map { $0.name }.sorted()

// Now lets see with prices
let increasedPrices = appPortifolio.map { $0.monthlyPrice * 1.5 }
print(increasedPrices)

// MARK: - Reduce
let numbersArray = [3, 5, 9, 12, 18]
let sum = numbersArray.reduce(0, +) // (initial value, operations), so we started with initial value 0 and added all numbers in numbersArray
print(sum)

// Different initial value
let sum2 = numbersArray.reduce(100, +) // (initial value, operations), so we started with initial value 0 and added all numbers in numbersArray
print(sum2)

// Different operation value
let sum3 = numbersArray.reduce(0, -) // (initial value, operations), so we started with initial value 0 and added all numbers in numbersArray
print(sum3)

// Different operation value with CLOSURE
let totalUsers = appPortifolio.reduce(0, { $0 + $1.users }) // The second parameter can be a closure
print(totalUsers)

// MARK: - Chaining
let recurringRevenue = appPortifolio.map { $0.monthlyPrice * Double($0.users) * 0.7 }.reduce(0, +)
print(recurringRevenue)

// MARK: - Compact Map
// comparativelly new additions to swift
// it removed NILs from an Array

let nilNumbers: [Int?] = [1, nil, 17, nil, 3, 7, nil, 99]
let notNilNumbers = nilNumbers.compactMap { $0 }
print(notNilNumbers)

// MARK: - Flat Map
// if you have an Array of Arrays, it flattens into a singles Array
let arrayOfArrays: [[Int]] = [[1, 2, 3],
                              [4, 5, 6],
                              [7, 8, 9]]
let singleArray = arrayOfArrays.flatMap { $0 }
print(singleArray)

// You can also do something with it before you flatten it
let singlesArray2 = arrayOfArrays.flatMap { $0.map { $0 * 2 } }
